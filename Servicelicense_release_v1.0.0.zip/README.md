# Servicelicense Module for FOSSBilling

Servicelicense is a free and open-source FOSSBilling module for distributing WordPress plugins with license keys, plus optional domain validation.

## Features

- License key generation per order/service
- Secure plugin ZIP download from client area (session-based; no public file exposure)
- Product-level configuration:
  - ZIP filename (stored in `BB_PATH_DATA/downloads/`)
  - Plugin version (shown to clients under the download button)
  - Changelog URL (shown to clients under the download button)
  - License prefix / format options (if enabled in your build)
  - Optional validation toggles (IP / hostname / path / version)
- Shows license details in the client area
- Domain management (valid domains list) and license reset action
- Backwards-compatible display for older orders (falls back to product config when order config is missing)

## Requirements

- FOSSBilling: 0.6+ (recommended; set minimum version in the extension directory entry)
- PHP: 8.0+

## Installation (manual)

1. Download the latest release ZIP.
2. Create a folder named `Servicelicense` in your FOSSBilling installation:

   `public_html/modules/Servicelicense/`

3. Extract the ZIP **into that folder** (so files like `Api/`, `Controller/`, `manifest.json` are directly inside it).
4. Clear cache (if enabled) and open Admin → Extensions to enable the module.

## Configuration

Admin → Products → (your product) → Module settings:

- `plugin_zip` — filename of your plugin ZIP placed in `BB_PATH_DATA/downloads/`
- `plugin_version` — shown to clients under the download button
- `changelog_url` — shown to clients under the download button

Then upload your plugin ZIP to:

`BB_PATH_DATA/downloads/`

## License

MIT License (see `LICENSE`).
