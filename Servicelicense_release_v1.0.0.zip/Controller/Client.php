<?php
namespace Box\Mod\Servicelicense\Controller;

class Client implements \FOSSBilling\InjectionAwareInterface
{
    protected ?\Pimple\Container $di = null;

    public function setDi(\Pimple\Container $di): void
    {
        $this->di = $di;
    }

    public function getDi(): ?\Pimple\Container
    {
        return $this->di;
    }

    public function register(\Box_App &$app)
    {
        // /servicelicense/download/81
        $app->get('/servicelicense/download/:id', 'download', ['id' => '[0-9]+'], static::class);

        // /servicelicense/download?order_id=81
        $app->get('/servicelicense/download', 'download_query', [], static::class);
    }

    public function download(\Box_App $app, $id)
    {
        // This is a CLIENT-area route. We are already inside an authenticated session.
        // Do not proxy through /api/client/* because a plain GET download link doesn't carry
        // the auth token used by the JS API client, which leads to "Authentication failed" (206).

        $client = $this->di['loggedin_client'];
        if (!$client instanceof \Model_Client) {
            throw new \FOSSBilling\Exception('Authentication failed', null, 206);
        }

        $order = $this->di['db']->findOne('ClientOrder', 'id = :id AND client_id = :client_id', [
            ':id' => (int) $id,
            ':client_id' => $client->id,
        ]);

        if (!$order instanceof \Model_ClientOrder) {
            throw new \FOSSBilling\Exception('Order not found');
        }

        if ($order->status !== 'active') {
            throw new \FOSSBilling\Exception('Order is not activated');
        }

        $orderService = $this->di['mod_service']('order');
        $s = $orderService->getOrderService($order);
        if (!$s instanceof \Model_ServiceLicense) {
            throw new \FOSSBilling\Exception('Order is not activated');
        }

        // Stream the file to the browser and exit.
        $service = $this->di['mod_service']('servicelicense');
        $service->sendPluginZip($order, $s);

        return null;
    }

    public function download_query(\Box_App $app)
    {
        $id = (int) $this->di['request']->get('order_id');
        return $this->download($app, $id);
    }
}
